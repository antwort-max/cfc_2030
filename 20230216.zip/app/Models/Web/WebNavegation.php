<?php

namespace App\Models\Web\Web;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class WebNavegation extends Model
{
    use HasFactory;
}
