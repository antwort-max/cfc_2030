<nav aria-label="breadcrumb">
    <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="{{ route('home') }}">Dasboard</a></li>
        <li class="breadcrumb-item"><a href="{{ route('config.commercial_area.index') }}">Areas comerciales</a></li>
        <li class="breadcrumb-item active" aria-current="page">Index</li>
    </ol>
</nav>
