<nav aria-label="breadcrumb">
    <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="{{ route('home') }}">Dashboard</a></li>
        <li class="breadcrumb-item"><a href="{{ route('config.tags.index') }}">Tags</a></li>
        <li class="breadcrumb-item active" aria-current="page">Tags</li>
    </ol>
</nav>