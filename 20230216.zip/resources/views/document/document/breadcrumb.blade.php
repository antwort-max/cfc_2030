<nav aria-label="breadcrumb">
    <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="{{ route('home') }}">Dashboard</a></li>
        <li class="breadcrumb-item"><a href="{{ route('document.document.index') }}">Documentos</a></li>
        <li class="breadcrumb-item active" aria-current="page">Documentos</li>
    </ol>
</nav>