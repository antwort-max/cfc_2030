<div class="container-fluid" style="background: red;">

    <div class="row">

        <div class="col text-center text-white text-bold">

            NUEVO CATALOGO ALBERDI

        </div>

    </div>

</div>