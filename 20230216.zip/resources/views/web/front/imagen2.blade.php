<section id="galeria" class="container-fluid mt-3">
   <div class="row">
        <div class="col-lg-6 col-md-6 col-sm-12">
            <img src="{{ asset('img/imagen/imagen-portada-terminaciones.jpg') }}" alt="">
        </div>
        <div class="col-lg-6 col-md-6 col-sm-12">
            <div class="row">
                <div class="col-lg-6 col-md-6 col-sm-12">
                    <img src="{{ asset('img/imagen/imagen-portada-local.jpg') }}" alt="">
                </div>
                <div class="col-lg-6 col-md-6 col-sm-12">
                    <img src="{{ asset('img/imagen/imagen-portada-despacho.jpg') }}" alt="">
                </div>
                <div class="col-lg-6 col-md-6 col-sm-12">
                    <img src="{{ asset('img/imagen/imagen-portada-ventas.jpg') }}" alt="">
                </div>
                <div class="col-lg-6 col-md-6 col-sm-12">
                    <img src="{{ asset('img/imagen/imagen-portada.jpg') }}" alt="">
                </div>
            </div>
        </div>
   </div>
</section>